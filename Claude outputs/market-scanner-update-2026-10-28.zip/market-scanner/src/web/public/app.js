// Market Scanner dashboard. Renders the existing scanner's JSON result plus server-built rows.
// All scanner text is inserted with textContent, never as HTML.
import { buildView, parseBudgetControls } from '/budget.js';
import { coverageFigures, coverageSentences, dashboardWording, exclusionBreakdown, leadCrossCheckWarnings, outlookView, plainCheck, profileContext, supplyText } from '/simple-view.js';

const $ = (id) => document.getElementById(id);
const state = { status: null, running: false, lastRequest: null, last: null, news: new Map(), wtb: new Map(), cmc: null, attention: null };
const MARKET = {
  crypto: { button: 'Scan Crypto', blurb: 'Movers and watchlist candidates from the CoinGecko top 500, using the existing scanner rules.', keyFlag: 'cryptoKeyConfigured', keyEnv: 'COINGECKO_DEMO_API_KEY', provider: 'CoinGecko', pace: 'about 0.7 s apart' },
  stocks: { button: 'Scan US Stocks', blurb: 'Live: the previous session\'s biggest gainers across all US stocks priced $5-$50 (ordinary stocks, ADRs and labelled ETFs; leveraged and inverse ETFs, warrants and units left out), checked with the scanner rules. End-of-day data; about 17 requests (3-4 minutes), plus about 12 once a week to refresh stock types. Offline: a fixed test list.', keyFlag: 'stocksKeyConfigured', keyEnv: 'POLYGON_API_KEY', provider: 'Massive', pace: 'about 12.5 s apart (free plan: 5 per minute)' },
};

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') node.className = v;
    else node.setAttribute(k, v);
  }
  for (const c of children) if (c !== null && c !== undefined && c !== false) node.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return node;
}

const usd = (n) => {
  if (n === null || n === undefined || !Number.isFinite(n)) return 'n/a';
  const a = Math.abs(n);
  if (a >= 1e9) return `$${(n / 1e9).toFixed(1)}B`;
  if (a >= 1e6) return `$${(n / 1e6).toFixed(a >= 1e8 ? 0 : 1)}M`;
  if (a >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(2)}`;
};
const price = (n) => (n === null || n === undefined ? 'n/a' : `$${n.toFixed(n >= 1 ? 2 : n >= 0.01 ? 4 : 8)}`);
const money = (n) => (n === null || n === undefined ? 'n/a' : `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
const pct = (n) => (n === null || n === undefined ? 'n/a' : `${n > 0 ? '+' : ''}${n.toFixed(1)}%`);
const signClass = (n) => (n > 0 ? 'pos' : n < 0 ? 'neg' : '');
const when = (iso) => (iso ? (/^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso : new Date(iso).toLocaleString()) : 'n/a');
const checked = (name) => document.querySelector(`input[name="${name}"]:checked`).value;

function updateControls() {
  const market = checked('market');
  const live = checked('mode') === 'live';
  const m = MARKET[market];
  $('scan-btn').textContent = m.button;
  $('market-blurb').textContent = m.blurb;
  const budget = $('max-requests');
  budget.disabled = !live || state.running;
  const cap = state.status?.maxRequestsCap ?? 160;
  budget.max = String(cap);
  $('budget-hint').textContent = live ? `Whole number 1-${cap}. The server enforces it; retries count toward it.` : 'Live only. Offline scans make no API requests.';
  $('live-warning').hidden = !live;
  if (live) {
    const n = Number(budget.value);
    const keyNote = state.status && !state.status[m.keyFlag] ? ` The ${m.keyEnv} environment variable is not set on the server, so a live scan will stop before any request.` : '';
    $('live-warning-text').textContent = `A live ${market} scan uses up to ${Number.isInteger(n) && n > 0 ? n : '?'} ${m.provider} request(s), ${m.pace} (change the limit under Settings). You will be asked to confirm.${keyNote}`;
  }
  $('unit-limit').disabled = $('no-unit-limit').checked;
  for (const id of ['scan-btn', 'rerun-btn']) $(id).disabled = state.running;
  document.querySelectorAll('input[name="mode"], input[name="market"]').forEach((r) => { r.disabled = state.running; });
}

async function loadStatus() {
  try {
    const r = await fetch('/api/status', { headers: { accept: 'application/json' } });
    state.status = await r.json();
    const saved = Number(prefs.get('maxRequests'));
    $('max-requests').value = String(Number.isInteger(saved) && saved >= 1 && saved <= (state.status.maxRequestsCap ?? 160) ? saved : state.status.defaultMaxRequests);
  } catch {
    showError('Could not reach the local server. Is "npm run web" still running?');
  }
  updateControls();
  maybeAutoScan();
}

// ---- remembered settings (this browser only) -----------------------------------------------------
const prefs = {
  get(k) { try { return localStorage.getItem(`market-scanner:${k}`); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(`market-scanner:${k}`, String(v)); } catch { /* storage blocked: settings just aren't remembered */ } },
};
const AUTO_SCAN_GAP_MS = 30 * 60_000;

/** Morning auto-scan: a live crypto scan when the page opens, if you turned it on and the key is set. */
function maybeAutoScan() {
  if (!$('auto-scan').checked || state.running || !state.status?.cryptoKeyConfigured) return;
  const last = Number(prefs.get('lastAutoScan')) || 0;
  if (Date.now() - last < AUTO_SCAN_GAP_MS) return; // a reload soon after should not spend requests again
  const n = Number($('max-requests').value);
  const cap = state.status.maxRequestsCap ?? 160;
  if (!Number.isInteger(n) || n < 1 || n > cap) return;
  prefs.set('lastAutoScan', Date.now());
  document.querySelector('input[name="market"][value="crypto"]').checked = true;
  document.querySelector('input[name="mode"][value="live"]').checked = true;
  updateControls();
  scan({ market: 'crypto', mode: 'live', maxRequests: n, confirmLive: true }, { auto: true });
}

function showError(text) {
  $('error').textContent = text;
  $('error').hidden = !text;
}

async function scan(request, { auto = false } = {}) {
  if (state.running) return;
  // The morning auto-scan is your standing consent (the Settings checkbox), so it skips the dialog.
  if (request.mode === 'live' && !auto) {
    const ok = window.confirm(`Run a LIVE ${request.market} scan?\n\nThis spends up to ${request.maxRequests} ${MARKET[request.market].provider} API request(s), counting retries.`);
    if (!ok) return;
    request = { ...request, confirmLive: true };
  }
  state.running = true;
  state.lastRequest = request;
  showError('');
  $('running').hidden = false;
  $('running-text').textContent = request.mode === 'live'
    ? `Scanning ${request.market} live (up to ${request.maxRequests} requests, ${MARKET[request.market].pace})…`
    : `Scanning the synthetic ${request.market} fixture (no API requests)…`;
  updateControls();
  try {
    const { market, ...body } = request;
    const r = await fetch(`/api/scan/${market === 'stocks' ? 'stocks' : 'crypto'}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-market-scanner': '1', accept: 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await r.json();
    if (!data.ok) showError(dashboardWording(data.error) || `The scan failed (HTTP ${r.status}).`);
    else {
      state.last = data;
      state.news = new Map(); // news panels belong to one scan
      state.wtb = new Map(); // so do "where to buy" panels
      state.cmc = null; // so does a cross-check
      state.attention = null; // and an attention check
      render();
      $('rerun-btn').hidden = false;
    }
  } catch {
    showError('Could not reach the local server. Is "npm run web" still running?');
  } finally {
    state.running = false;
    $('running').hidden = true;
    updateControls();
  }
}

function currentRequest() {
  const market = checked('market');
  if (checked('mode') === 'offline') return { market, mode: 'offline' };
  const n = Number($('max-requests').value);
  const cap = state.status?.maxRequestsCap ?? 160;
  if (!Number.isInteger(n) || n < 1 || n > cap) {
    showError(`Max API requests must be a whole number from 1 to ${cap}.`);
    return null;
  }
  return { market, mode: 'live', maxRequests: n };
}

// ---- results -----------------------------------------------------------------------------------

/** Direction filter (display only): keeps coins whose short-period change matches the choice. */
function keepMove(pct) {
  const dir = $('direction').value;
  if (dir === 'both') return true;
  return pct !== null && pct !== undefined && (dir === 'up' ? pct > 0 : pct < 0);
}

function stat(label, value, sub) {
  return el('div', { class: 'stat' }, el('div', { class: 'label' }, label), el('div', { class: 'value' }, value), sub ? el('div', { class: 'sub' }, sub) : null);
}

const STATUS_LABEL = { qualified: 'Qualified', over_display_limit: 'Qualified (over display limit)', below_threshold: 'Below threshold', no_pattern: 'No signal pattern' };

function classificationCell(c, row) {
  if (!c) {
    // Stocks: the security type from Massive's ticker reference (live market-wide scans), when known.
    const sec = row?.security;
    return sec
      ? el('div', {}, el('span', { class: `chip ${sec.kind === 'etf' ? 'watch' : 'cat'}` }, sec.label), el('div', { class: 'sym' }, sec.basis))
      : el('span', { class: 'muted' }, 'Security type not checked');
  }
  const basis = { provider: 'provider data', curated_list: 'curated list', heuristic: 'heuristic', none: 'no reliable evidence' }[c.basis];
  return el('div', {},
    el('span', { class: `chip ${c.category === 'unknown' ? 'dim' : 'cat'}` }, c.label),
    el('div', { class: 'sym' }, basis),
    el('details', {}, el('summary', {}, 'Evidence'), el('ul', {}, ...(c.evidence.length ? c.evidence : ['none']).map((e) => el('li', {}, e)), c.note ? el('li', {}, `Note: ${c.note}`) : null)));
}

function riskCell(row) {
  const r = row.risk;
  const lines = [];
  if (row.market === 'crypto') {
    lines.push(`24h range: ${r.range24hPct === null ? 'n/a' : `${r.range24hPct.toFixed(1)}%`}; from 24h high: ${pct(r.fromHigh24hPct)}`);
    lines.push(`From all-time high: ${pct(r.athChangePct)}${r.athDate ? ` (ATH ${when(r.athDate)})` : ''}`);
    lines.push(`Turnover: ${r.turnoverPct === null ? 'n/a' : `${r.turnoverPct.toFixed(1)}%`} of market cap; data ${r.dataAgeMinutes === null ? 'age n/a' : `${r.dataAgeMinutes} min old`}`);
    const v = r.volumeReliability;
    lines.push(`Volume baseline: ${v.insufficient ? `not measured (${v.validDays} valid days)` : `${v.highlyVariable ? 'HIGHLY VARIABLE' : 'stable'} (Q3/Q1 ${v.iqrRatio.toFixed(1)}x)`}`);
  } else {
    lines.push(`Session ${r.sessionDate}; ${usd(r.dollarVolume)} traded`);
    if (r.dayRangePct !== null && r.dayRangePct !== undefined) lines.push(`Day's range: ${r.dayRangePct.toFixed(1)}%; close vs day's high: ${pct(r.fromDayHighPct)}${r.gapPct !== null ? `; open vs previous close: ${pct(r.gapPct)}` : ''}`);
  }
  return el('div', { class: 'risk' },
    ...lines.map((l) => el('div', {}, l)),
    ...r.flags.map((f) => el('div', { class: 'flag' }, f)),
    el('details', {}, el('summary', {}, 'Period and limits'), el('ul', {}, el('li', {}, `Period: ${r.period}`), ...r.unavailable.map((u) => el('li', {}, `Not available: ${u}`)))));
}

// ---- compact row summary --------------------------------------------------------------------------
// Why it is listed, evidence quality, key risk, attention (only after the optional check) and the
// next step, from the server's row brief (src/web/brief.ts). Every caution stays in the row's
// "Cautions, category & volatility" details; the market signal stays in the Signal column.

const EVIDENCE_LABEL = { test_data: 'Test data', limited: 'Limited', single_source: 'One source' };

function attentionText(row) {
  const d = state.attention?.data;
  if (row.market !== 'crypto' || !d) return null;
  const hit = d.coins.find((c) => c.id === row.id);
  return hit ? `#${hit.trendRank} of ${d.coins.length} on CoinGecko's trending searches (24h)` : `not among CoinGecko's ${d.coins.length} trending searches`;
}

function briefView(row) {
  const b = row.brief;
  if (!b) return null;
  const att = attentionText(row);
  return el('div', { class: 'brief' },
    b.reason ? el('div', { class: 'brief-reason' }, b.reason) : null,
    el('div', {}, el('span', { class: `ev ev-${b.evidence.level}` }, `Evidence: ${EVIDENCE_LABEL[b.evidence.level]}`), ' ', el('span', { class: 'sym' }, b.evidence.text)),
    b.keyRisk ? el('div', { class: 'brief-risk' }, `Key risk: ${b.keyRisk}`) : null,
    att ? el('div', { class: 'sym' }, `Attention: ${att}`) : null,
    el('div', { class: 'brief-next' }, `Next: ${b.next}`));
}

function rowView({ row, afford }) {
  const fit = afford.passesBudget && afford.passesUnitPrice;
  return el('tr', {},
    el('td', { class: 'asset' }, el('div', { class: 'name' }, row.name), el('div', { class: 'sym' }, row.market === 'crypto' ? `${row.symbol} · ${row.id}` : [row.name === row.symbol ? null : row.symbol, row.security?.label].filter(Boolean).join(' · ') || row.symbol),
      briefView(row),
      ...(state.leadById?.has(row.id) ? leadNotes(state.leadById.get(row.id)).slice(row.brief ? 1 : 0) : [])),
    el('td', {}, el('span', { class: `chip ${row.signal.category === 'Mover' ? 'mover' : row.signal.category === 'Watchlist' ? 'watch' : 'dim'}` }, row.signal.category ?? STATUS_LABEL[row.signal.status]),
      el('div', { class: 'sym' }, [row.signal.category ? STATUS_LABEL[row.signal.status] : null, row.signal.score === null ? null : `score ${row.signal.score}/${row.signal.maxScore}`, row.volumeMultiple === null ? null : `${row.volumeMultiple.toFixed(2)}x volume`].filter(Boolean).join(' · '))),
    el('td', { class: 'num' }, price(row.unitPrice)),
    el('td', { class: `num ${signClass(row.change.short.value)}` }, `${pct(row.change.short.value)} ${row.change.short.label}`,
      el('div', { class: `sym ${signClass(row.change.long.value)}` }, `${pct(row.change.long.value)} ${row.change.long.label}`)),
    el('td', {}, el('span', { class: `chip ${fit ? 'complete' : 'partial'}` }, fit ? 'Within limits' : 'Outside limits'),
      el('div', { class: 'sym' }, `${afford.maxUnits.toLocaleString()} units ≈ ${money(afford.totalCost)} before fees`),
      afford.reason ? el('div', { class: 'sym' }, afford.reason) : null),
    el('td', { class: 'row-actions' },
      el('div', { class: 'action-line' }, newsButton(row), wtbButton(row), snapshotButton(row)),
      row.why.length ? el('details', {}, el('summary', {}, 'Why'), el('ul', {}, ...row.why.map((w) => el('li', {}, w)))) : null,
      el('details', {}, el('summary', {}, 'Cautions, category & volatility'),
        el('div', { class: 'more' }, ...(row.brief && state.leadById?.has(row.id) ? leadNotes(state.leadById.get(row.id)).slice(0, 1) : []), classificationCell(row.classification, row), riskCell(row),
          ...row.warnings.filter((w) => !row.risk.flags.includes(w)).map((w) => el('div', { class: 'sym' }, w)),
          el('div', { class: 'sym' }, `Price as of ${when(row.priceAsOf)}`)))));
}

// ---- news panel ("Why it may be moving") -------------------------------------------------------
// Opened per asset by the user; nothing is fetched until then. Live news needs a confirmation and
// spends one Massive request; cached results (up to an hour) are free. Article text is untrusted:
// it is inserted as text only, and links open in a new tab without a referrer.

const ROLE = {
  possible_catalyst: (s) => [`Possible catalyst (${s} evidence)`, 'cat'],
  reported_after: () => ['Published after the move', 'dim'],
  background: () => ['Background only', 'dim'],
  unplaced: () => ['Time unknown', 'dim'],
};
const VERDICT_CLASS = { possible_catalyst: 'cat', conflicting: 'partial', unconfirmed: 'dim', no_news: 'dim', no_source: 'dim' };

function newsButton(row) {
  const open = state.news.get(row.key)?.open;
  const b = el('button', { type: 'button', class: 'linkish' }, open ? 'Hide news' : 'News & why it may be moving');
  b.addEventListener('click', () => toggleNews(row));
  return b;
}

function newsLimit() {
  const n = Number($('news-limit').value);
  const max = state.status?.newsMaxLimit ?? 20;
  return Number.isInteger(n) && n >= 1 && n <= max ? n : null;
}

async function loadNews(row, { refresh = false, confirmLive = false } = {}) {
  const entry = state.news.get(row.key) ?? { open: true };
  const limit = newsLimit();
  if (limit === null) {
    state.news.set(row.key, { ...entry, open: true, loading: false, error: `News articles per asset must be a whole number from 1 to ${state.status?.newsMaxLimit ?? 20}.` });
    return render();
  }
  state.news.set(row.key, { ...entry, open: true, loading: true, error: null, needsConfirm: false });
  render();
  try {
    const r = await fetch(`/api/news/${row.market === 'stocks' ? 'stocks' : 'crypto'}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-market-scanner': '1', accept: 'application/json' },
      body: JSON.stringify({ key: row.key, limit, refresh, confirmLive }),
    });
    const data = await r.json();
    const next = { open: true, loading: false, data: data.ok ? data : entry.data }; // keep an earlier result visible on failure
    if (!data.ok) {
      next.needsConfirm = Boolean(data.needsConfirm);
      next.error = data.needsConfirm ? null : data.error || `The news request failed (HTTP ${r.status}).`;
    }
    state.news.set(row.key, next);
  } catch {
    state.news.set(row.key, { ...entry, open: true, loading: false, error: 'Could not reach the local server.' });
  }
  render();
}

function toggleNews(row) {
  const entry = state.news.get(row.key);
  if (entry?.open) {
    state.news.set(row.key, { ...entry, open: false });
    return render();
  }
  if (entry?.data) {
    state.news.set(row.key, { ...entry, open: true });
    return render();
  }
  loadNews(row);
}

function confirmAndLoad(row, refresh) {
  const ok = window.confirm(`Fetch live news for ${row.symbol}?\n\nThis spends 1 Massive API request (the free plan allows 5 per minute, shared with stock scans).`);
  if (ok) loadNews(row, { refresh, confirmLive: true });
}

function movementBlock(row) {
  const r = row.risk;
  const items = [
    `Change: ${pct(row.change.short.value)} ${row.change.short.label}, ${pct(row.change.long.value)} ${row.change.long.label}`,
    row.volumeMultiple === null ? 'Volume multiple: not available' : `Volume: ${row.volumeMultiple.toFixed(2)}x the baseline median`,
  ];
  if (row.market === 'crypto') {
    items.push(r.range24hPct === null ? 'Intraday: 24h range not available from this data' : `24h range ${r.range24hPct.toFixed(1)}%; ${pct(r.fromHigh24hPct)} from the 24h high`);
    if (r.athChangePct !== null) items.push(`${pct(r.athChangePct)} from the all-time high`);
  } else {
    items.push('Intraday range: not available (end-of-day bars only)');
  }
  items.push(`Data: ${row.priceBasis}, ${when(row.priceAsOf)} [${row.dataKind === 'test_data' ? 'TEST DATA' : 'provider data'}]`);
  return el('ul', { class: 'notes' }, ...items.map((i) => el('li', {}, i)), ...r.flags.map((f) => el('li', { class: 'flag' }, f)));
}

function articleCard(x) {
  const a = x.article;
  const [label, cls] = ROLE[x.role](x.strength);
  const link = a.url && /^https?:\/\//.test(a.url)
    ? el('a', { href: a.url, target: '_blank', rel: 'noopener noreferrer nofollow' }, 'View original article ↗')
    : el('span', { class: 'muted' }, 'Original link unavailable (missing or unsafe link from the provider)');
  return el('article', { class: 'news-card' },
    el('div', { class: 'news-head' }, el('span', { class: `chip ${cls}` }, label), el('span', { class: 'sym' }, `${a.publisher} · ${a.publishedUtc ? when(a.publishedUtc) : 'publication time unknown'}`)),
    el('div', { class: 'news-title' }, a.title),
    a.description ? el('p', { class: 'news-desc' }, el('b', {}, 'Summary (publisher/provider text, not verified): '), a.description) : el('p', { class: 'muted' }, 'No summary provided.'),
    el('p', { class: 'news-desc' }, el('b', {}, 'Reported fact: '), x.fact),
    el('p', { class: 'news-desc' }, el('b', {}, 'Why it may be relevant: '), x.relevance),
    a.sentiment ? el('p', { class: 'sym' }, `Provider's automated sentiment (AI-generated, not verified): ${a.sentiment}${a.sentimentReasoning ? ` (${a.sentimentReasoning})` : ''}`) : null,
    link);
}

function newsPanelRow(row) {
  const entry = state.news.get(row.key);
  if (!entry?.open) return null;
  const body = el('div', { class: 'news-panel' }, el('h4', {}, `Market movement & news: ${row.name} (${row.symbol})`), movementBlock(row));
  const d = entry.data;
  if (entry.loading) body.append(el('div', { class: 'running' }, el('span', { class: 'spinner' }), 'Loading news…'));
  if (entry.error) body.append(el('div', { class: 'error' }, entry.error));
  if (entry.needsConfirm) {
    const b = el('button', { type: 'button', class: 'secondary' }, 'Fetch live news (1 Massive request)');
    b.addEventListener('click', () => confirmAndLoad(row, false));
    body.append(el('div', { class: 'warning' }, 'Live news is fetched only when you ask.', b));
  }
  if (d) {
    const s = d.assessment;
    body.append(el('div', { class: 'verdict' },
      el('div', {}, el('b', {}, 'Why it may be moving: '), el('span', { class: `chip ${VERDICT_CLASS[s.verdict.kind]}` }, s.verdict.label)),
      el('p', {}, s.movement), el('p', {}, s.verdict.text),
      ...s.notes.map((n) => el('p', { class: 'sym' }, n))));
    if (d.dataKind === 'test_data') body.append(el('div', { class: 'banner test' }, 'TEST DATA: synthetic articles with invented publishers and example.com links. NOT real news.'));
    if (d.warning) body.append(el('div', { class: 'warning' }, d.warning));
    if (d.source === null) body.append(el('p', { class: 'empty' }, 'No news source is configured for crypto, so no articles were checked.'));
    else if (s.articles.length === 0) body.append(el('p', { class: 'empty' }, 'No relevant news found for this asset.'));
    else body.append(el('div', { class: 'news-list' }, ...s.articles.map(articleCard)));
    const dropped = [s.droppedUnrelated ? `${s.droppedUnrelated} unrelated article(s) hidden` : '', s.droppedDuplicates ? `${s.droppedDuplicates} duplicate(s) removed` : '', d.skipped ? `${d.skipped} malformed article(s) skipped` : ''].filter(Boolean);
    body.append(el('ul', { class: 'notes' },
      d.source ? el('li', {}, `Source: ${d.source}${d.attribution ? `. ${d.attribution}` : ''}`) : null,
      d.fetchedAt ? el('li', {}, `Fetched ${when(d.fetchedAt)}${d.fromCache ? ' (cached; no request made)' : ''}; requests used: ${d.requestsUsed}; up to ${d.limit} article(s).`) : null,
      dropped.length ? el('li', {}, dropped.join('; ')) : null,
      ...d.coverage.map((c) => el('li', {}, c))));
    if (d.market === 'stocks' && d.mode === 'live') {
      const b = el('button', { type: 'button', class: 'secondary' }, 'Refresh news (1 request)');
      b.addEventListener('click', () => confirmAndLoad(row, true));
      body.append(b);
    }
  }
  return el('tr', { class: 'news-row' }, el('td', { colspan: '6' }, body));
}

// ---- track record (candidate journal) -------------------------------------------------------------
// From the server's journal of earlier LIVE scans on this computer; no request is made. One line on the
// page; the numbers behind it are folded.

function horizonText(st) {
  if (!st.measured) return `after ${st.horizon}d: not measured yet`;
  return `after ${st.horizon}d: ${st.up} of ${st.measured} up (median ${pct(st.medianPct)})`;
}

function trackRecordView(tr, market) {
  if (!tr) return null;
  const label = market === 'stocks' ? 'stock' : 'crypto';
  if (!tr.candidates) {
    return el('p', { class: 'kv' }, el('b', {}, 'Track record: '), `starts with your first live ${label} scan. Each candidate is checked 1, 3 and 7 days later against later scans, at no extra request.`);
  }
  const three = tr.stats.find((x) => x.horizon === 3);
  const lead = three && three.measured ? horizonText(three) : horizonText(tr.stats[0]);
  const row = (c) => el('tr', {},
    el('td', {}, el('div', { class: 'name' }, c.symbol), el('div', { class: 'sym' }, c.name)),
    el('td', {}, when(c.flaggedAt)),
    el('td', {}, `${c.category}${c.score !== null ? ` ${c.score}/${c.maxScore}` : ''}`),
    el('td', { class: 'num' }, price(c.price)),
    ...[1, 3, 7].map((h) => el('td', { class: `num ${signClass(c.after[h])}` }, c.after[h] === null ? '—' : pct(c.after[h]))));
  return el('div', { class: 'kv' },
    el('b', {}, 'Track record: '), `${tr.candidates} ${label} candidate(s) flagged by your live scans since ${when(tr.firstScan)}; ${lead}.`,
    el('details', {}, el('summary', {}, 'How earlier candidates did'),
      el('ul', { class: 'notes' }, ...[{ category: 'All', stats: tr.stats }, ...tr.byCategory].map((g) => el('li', {}, `${g.category}: ${g.stats.map(horizonText).join('; ')}`))),
      tr.recent.length ? el('div', { class: 'table-wrap' }, el('table', {},
        el('thead', {}, el('tr', {}, ...['Asset', 'First flagged', 'Signal', 'Price then', '1 day', '3 days', '7 days'].map((h) => el('th', {}, h)))),
        el('tbody', {}, ...tr.recent.map(row)))) : null,
      el('ul', { class: 'notes' }, ...tr.notes.map((n) => el('li', {}, n)))));
}

// ---- save to the Asset Snapshot Log ----------------------------------------------------------------
// Opens your Snapshot Log (a claude.ai page) with this row's numbers in the link, so its form is
// pre-filled and you only click Save there. Nothing is sent anywhere else and no API request is made.
// The numbers ride in the link's #fragment, which browsers never send to a server.

const SNAPSHOT_LOG_URL = 'https://claude.ai/artifact/LHSo3rMd39sMP9R71K1MJ8';

function snapshotPayload(row) {
  const r = row.risk;
  const num = (n) => (typeof n === 'number' && Number.isFinite(n) ? n : null);
  // Market cap from 24h volume and turnover (volume / market cap), both from the same provider snapshot.
  const mcap = row.market === 'crypto' && num(row.volumeUsd) !== null && num(r.turnoverPct) ? row.volumeUsd / (r.turnoverPct / 100) : null;
  const w = state.wtb.get(row.key)?.data?.result;
  const exchanges = w ? [...w.cex, ...w.dex].slice(0, 15).map((v) => `${v.exchange}${v.pairs.length ? ` ${v.pairs[0]}` : ''}`) : [];
  const asOf = row.priceAsOf ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(row.priceAsOf) ? `${row.priceAsOf}T16:00:00-05:00` : row.priceAsOf) : new Date();
  const pad = (x) => String(x).padStart(2, '0');
  const note = [
    'From Market Scanner',
    row.signal.category ? `${row.signal.category} ${row.signal.score}/${row.signal.maxScore}` : STATUS_LABEL[row.signal.status],
    row.market === 'stocks' && num(row.change.long.value) !== null ? `5d ${pct(row.change.long.value)}` : null,
  ].filter(Boolean).join(', ');
  // Everything else the scanner knows about this row, as "label: value" pairs (the Snapshot Log's details field).
  const lead = state.leadById?.get(row.id);
  const details = [
    row.signal.score !== null ? `Signal: ${row.signal.category ?? STATUS_LABEL[row.signal.status]} (evidence ${row.signal.score}/${row.signal.maxScore})` : `Signal: ${STATUS_LABEL[row.signal.status]}`,
    row.classification ? `Category: ${row.classification.label}` : null,
    row.market === 'crypto' && num(r.range24hPct) !== null ? `24h range: ${r.range24hPct.toFixed(1)}%` : null,
    row.market === 'crypto' && num(r.fromHigh24hPct) !== null ? `From 24h high: ${pct(r.fromHigh24hPct)}` : null,
    row.market === 'crypto' && num(r.athChangePct) !== null ? `From all-time high: ${pct(r.athChangePct)}` : null,
    row.market === 'crypto' && num(r.turnoverPct) !== null ? `Turnover: ${r.turnoverPct.toFixed(1)}% of market cap` : null,
    ...(lead?.explanation?.warnings ?? []).map((w) => `Caution: ${w.text}`),
    ...r.flags.map((f) => `Flag: ${f}`),
  ].filter(Boolean).join('; ').slice(0, 1000);
  return {
    a: row.symbol, k: row.market === 'stocks' ? 'stock' : 'crypto',
    p: num(row.unitPrice), v: num(row.volumeUsd), r: num(row.volumeMultiple) === null ? null : Math.round(row.volumeMultiple * 100) / 100, m: mcap === null ? null : Math.round(mcap),
    c: num(row.change.short.value), w: row.market === 'crypto' ? num(row.change.long.value) : null,
    e: exchanges.join(', '),
    d: `${asOf.getFullYear()}-${pad(asOf.getMonth() + 1)}-${pad(asOf.getDate())}`,
    t: row.market === 'stocks' ? '16:00' : `${pad(asOf.getHours())}:${pad(asOf.getMinutes())}`,
    n: note,
    x: details,
  };
}

/** base64url of the UTF-8 JSON: only letters, digits, - and _ (the characters a claude.ai link's #fragment keeps). */
function snapshotLink(row) {
  const json = JSON.stringify(snapshotPayload(row));
  const b64 = btoa(String.fromCharCode(...new TextEncoder().encode(json))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `${SNAPSHOT_LOG_URL}#add~${b64}`;
}

/** One link carrying several rows (#adds~): the Snapshot Log shows them as a list to save together. */
function snapshotBatchLink(rows) {
  const json = JSON.stringify(rows.map(snapshotPayload));
  const b64 = btoa(String.fromCharCode(...new TextEncoder().encode(json))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `${SNAPSHOT_LOG_URL}#adds~${b64}`;
}
const SEND_TOP = 10;

function snapshotButton(row) {
  if (row.dataKind === 'test_data') return el('span', { class: 'sym', title: 'Run a live scan to save real numbers' }, 'Save to Snapshot Log (live scans only)');
  return el('a', { class: 'linkish', href: snapshotLink(row), target: '_blank', rel: 'noopener noreferrer', title: 'Opens your Asset Snapshot Log with these numbers filled in' }, 'Save to Snapshot Log ↗');
}

// ---- where to buy -------------------------------------------------------------------------------
// Opened per asset by the user. Crypto (live) spends one CoinGecko request after a confirmation;
// cached results (up to an hour) are free. Stocks never make a request. Exchange names and links
// come from the provider: inserted as text, links only when https, opened without a referrer.

const US_LABEL = { serves_us: ['Generally serves US customers', 'complete'], restricts_us: ['Generally restricts US customers', 'partial'], unknown: ['US access not checked', 'dim'] };
const TRUST_LABEL = { green: 'CoinGecko trust: green', yellow: 'CoinGecko trust: yellow', red: 'CoinGecko trust: red' };

function wtbButton(row) {
  const open = state.wtb.get(row.key)?.open;
  const b = el('button', { type: 'button', class: 'linkish' }, open ? 'Hide where to buy' : 'Where to buy');
  b.addEventListener('click', () => toggleWtb(row));
  return b;
}

async function loadWtb(row, { refresh = false, confirmLive = false } = {}) {
  const entry = state.wtb.get(row.key) ?? { open: true };
  state.wtb.set(row.key, { ...entry, open: true, loading: true, error: null, needsConfirm: false });
  render();
  try {
    const r = await fetch(`/api/where-to-buy/${row.market === 'stocks' ? 'stocks' : 'crypto'}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-market-scanner': '1', accept: 'application/json' },
      body: JSON.stringify({ key: row.key, refresh, confirmLive }),
    });
    const data = await r.json();
    const next = { open: true, loading: false, data: data.ok ? data : entry.data };
    if (!data.ok) {
      next.needsConfirm = Boolean(data.needsConfirm);
      next.error = data.needsConfirm ? null : data.error || `The lookup failed (HTTP ${r.status}).`;
    }
    state.wtb.set(row.key, next);
  } catch {
    state.wtb.set(row.key, { ...entry, open: true, loading: false, error: 'Could not reach the local server.' });
  }
  render();
}

function toggleWtb(row) {
  const entry = state.wtb.get(row.key);
  if (entry?.open) {
    state.wtb.set(row.key, { ...entry, open: false });
    return render();
  }
  if (entry?.data) {
    state.wtb.set(row.key, { ...entry, open: true });
    return render();
  }
  loadWtb(row);
}

function confirmWtb(row, refresh) {
  const ok = window.confirm(`Look up where ${row.symbol} trades?\n\nThis spends 1 CoinGecko API request.`);
  if (ok) loadWtb(row, { refresh, confirmLive: true });
}

function venueRow(v) {
  const [usText, usCls] = US_LABEL[v.usAccess];
  const link = v.tradeUrl && /^https:\/\//.test(v.tradeUrl) ? el('a', { href: v.tradeUrl, target: '_blank', rel: 'noopener noreferrer nofollow' }, 'Open market ↗') : el('span', { class: 'muted' }, 'no link');
  return el('tr', {},
    el('td', {}, el('div', { class: 'name' }, v.exchange), v.kind === 'cex' ? el('span', { class: `chip ${usCls}` }, usText) : null),
    el('td', {}, v.pairs.join(', ')),
    el('td', { class: 'num' }, usd(v.volumeUsd)),
    el('td', {}, v.trust ? TRUST_LABEL[v.trust] : 'n/a'),
    el('td', {}, link));
}

function venueTable(title, venues) {
  if (!venues.length) return el('div', {}, el('h5', {}, title), el('p', { class: 'empty' }, 'None found.'));
  return el('div', {}, el('h5', {}, title), el('div', { class: 'table-wrap' }, el('table', { class: 'wtb-table' },
    el('thead', {}, el('tr', {}, ...['Exchange', 'Pairs', '24h volume', 'Trust', 'Link'].map((h) => el('th', {}, h)))),
    el('tbody', {}, ...venues.map(venueRow)))));
}

function wtbPanelRow(row) {
  const entry = state.wtb.get(row.key);
  if (!entry?.open) return null;
  const body = el('div', { class: 'news-panel' }, el('h4', {}, `Where to buy: ${row.name} (${row.symbol})`));
  if (entry.loading) body.append(el('div', { class: 'running' }, el('span', { class: 'spinner' }), 'Looking up markets…'));
  if (entry.error) body.append(el('div', { class: 'error' }, entry.error));
  if (entry.needsConfirm) {
    const b = el('button', { type: 'button', class: 'secondary' }, 'Look up live markets (1 CoinGecko request)');
    b.addEventListener('click', () => confirmWtb(row, false));
    body.append(el('div', { class: 'warning' }, 'Live markets are looked up only when you ask.', b));
  }
  const d = entry.data;
  if (d) {
    if (d.dataKind === 'test_data') body.append(el('div', { class: 'banner test' }, 'TEST DATA: invented exchanges and example.com links. NOT real listings.'));
    if (d.warning) body.append(el('div', { class: 'warning' }, d.warning));
    if (d.result) {
      const w = d.result;
      body.append(venueTable('Centralized exchanges (US-friendly first, then by volume)', w.cex), venueTable('Decentralized exchanges (swap from your own wallet)', w.dex));
      if (w.contracts.length) body.append(el('p', { class: 'news-desc' }, el('b', {}, 'Contract address(es) seen on DEX markets: '), w.contracts.join(', ')));
      if (d.coingeckoPage) body.append(el('p', {}, el('a', { href: d.coingeckoPage, target: '_blank', rel: 'noopener noreferrer nofollow' }, 'Confirm the official contract on CoinGecko ↗')));
    }
    body.append(el('ul', { class: 'notes' },
      d.source ? el('li', {}, `Source: ${d.source}${d.attribution ? `. ${d.attribution}` : ''}`) : null,
      d.fetchedAt ? el('li', {}, `Fetched ${when(d.fetchedAt)}${d.fromCache ? ' (cached; no request made)' : ''}; requests used: ${d.requestsUsed}.${d.result ? ` ${d.result.totalMarkets} market(s) read, ${d.result.dropped} stale/anomalous/unusable skipped.` : ''}` ) : null,
      ...d.notes.map((n) => el('li', {}, n))));
    if (d.market === 'crypto' && d.mode === 'live') {
      const b = el('button', { type: 'button', class: 'secondary' }, 'Refresh markets (1 request)');
      b.addEventListener('click', () => confirmWtb(row, true));
      body.append(b);
    }
  }
  return el('tr', { class: 'news-row' }, el('td', { colspan: '6' }, body));
}

// ---- discovery (crypto research leads) --------------------------------------------------------
// From the scan result only: tiers by evidence strength, each with why it was surfaced and what
// limits the evidence. Informational; scores and the table below are unchanged.


/**
 * The scan's own warnings for one coin, in plain English (src/scanner/lead-quality.ts): every caution
 * in priority order, then (only after a CoinMarketCap cross-check of this scan) that check's warnings.
 * Shown under the coin in the table, and in the "moved but not checked" list.
 */
function leadNotes(e) {
  const x = e.explanation;
  const second = leadCrossCheckWarnings(e, state.cmc?.data, state.last?.result?.evaluatedAt);
  return [
    x && x.warnings.length ? el('ul', { class: 'plain-warnings' }, ...x.warnings.map((w) => el('li', { class: 'plain-caution' }, `Caution: ${w.text}`))) : null,
    second.length ? el('ul', { class: 'plain-warnings' }, ...second.map((w) => el('li', { class: 'plain-caution' }, `Second source: ${w.text}`))) : null,
  ];
}

/** One coin the scanner could not evaluate (too little or unreliable data): reason, cautions, evidence. */
function discoveryEntry(e) {
  const x = e.explanation;
  return el('li', { class: 'lead' },
    el('div', {}, el('span', { class: 'name' }, e.name), ' ', el('span', { class: 'sym' }, `${e.symbol} · ${e.id} · ${pct(e.change24hPct)} 24h`)),
    x ? el('p', { class: 'plain' }, x.reason) : null,
    ...leadNotes(e),
    el('details', {}, el('summary', {}, 'Evidence'),
      el('ul', { class: 'notes' }, ...e.reasons.map((r) => el('li', {}, r))),
      e.caveats.length ? el('ul', { class: 'notes caveats' }, ...e.caveats.map((c) => el('li', { class: 'flag' }, c))) : null));
}

/**
 * What the table cannot show: coins that moved but could not be checked (folded), the scan's
 * coverage notes, and the CoinMarketCap cross-check. Coins the scanner did evaluate (high-priority
 * and watchlist) are in the table above, with their cautions under the name.
 */
function discoveryView(d, coverageShown) {
  const box = el('div', { class: 'discovery' });
  const list = d.insufficientData.filter((e) => keepMove(e.change24hPct));
  const c = d.coverage;
  const notes = c.notes.flatMap((n) => {
    if (!coverageShown) return [n];
    if (/ passed every filter and were evaluated against their own volume baseline\.$/.test(n)) return []; // the Coverage line states this count
    if (n.startsWith('Incomplete scan:')) return ['Eligible assets whose history was not obtained (see Coverage above) are listed here if they showed snapshot activity; the rest were not evaluated.'];
    return [n];
  });
  box.append(el('details', { class: 'section' },
    el('summary', {}, `Moved but not checked (${list.length})`),
    el('p', { class: 'muted small' }, 'Activity in the market snapshot, but not enough reliable data for the scanner to evaluate it. Not in the table above.'),
    list.length ? el('ul', { class: 'leads' }, ...list.map(discoveryEntry)) : el('p', { class: 'empty' }, 'None in this scan.'),
    el('ul', { class: 'notes' },
      el('li', {}, `${c.withActivity} asset(s) showed snapshot activity; ${c.withActivityNotEvaluated} of them could not be evaluated for lack of reliable data.`),
      ...notes.map((n) => el('li', {}, n)))));
  box.append(cmcView());
  box.append(attentionView());
  return box;
}

// ---- CoinMarketCap cross-check (second source for the research leads) ----------------------------
// Runs only on click. Offline scans use TEST DATA; live scans send 1 request after you confirm.
// CMC's terms require prominent attribution with a link wherever its data is shown.

const MATCH_TEXT = {
  matched: (m) => `matched to CoinMarketCap "${m.cmc.name}" (CMC id ${m.cmc.id}${m.cmc.rank ? `, rank ${m.cmc.rank}` : ''}) by ${m.basis === 'name_and_slug' ? 'name and slug' : m.basis}`,
  ambiguous: (m) => `ambiguous: ${m.candidates.length} CoinMarketCap coins share this symbol and name (${m.candidates.map((c) => `id ${c.id}`).join(', ')}); not matched`,
  unmatched: (m) => `not matched: CoinMarketCap uses this symbol for ${m.candidates.map((c) => `"${c.name}"`).join(', ')}`,
  not_found: () => 'not found in CoinMarketCap\'s top 500',
};
const VERDICT_CHIP = { agrees: ['Agrees', 'complete'], differs: ['Differs', 'partial'], partial: ['Partly compared', 'dim'], not_compared: ['Not compared', 'dim'] };

function cmcAttribution(a, small = false) {
  const ok = a && typeof a.url === 'string' && a.url.startsWith('https://coinmarketcap.com');
  const link = el('a', { href: ok ? a.url : 'https://coinmarketcap.com/', target: '_blank', rel: 'noopener noreferrer' }, 'CoinMarketCap.com');
  return el(small ? 'span' : 'div', { class: small ? 'sym' : 'attribution' }, 'Data provided by ', link);
}

async function loadCmc(refresh = false) {
  state.cmc = { loading: true, data: state.cmc?.data ?? null, error: null };
  render();
  const send = (extra) => fetch('/api/crypto/cmc-check', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-market-scanner': '1', accept: 'application/json' },
    body: JSON.stringify({ refresh, ...extra }),
  }).then(async (r) => [r, await r.json()]);
  try {
    let [r, data] = await send({});
    if (r.status === 428 && data.needsConfirm) {
      if (!window.confirm(`Cross-check the research leads with CoinMarketCap?\n\n${data.error}\n\nRequests this session: ${data.cmcRequestsThisSession} of ${data.cmcSessionLimit}.`)) {
        state.cmc = { loading: false, data: state.cmc?.data ?? null, error: null };
        return render();
      }
      [r, data] = await send({ confirmLive: true });
    }
    state.cmc = data.ok ? { loading: false, data, error: null } : { loading: false, data: state.cmc?.data ?? null, error: data.error || `The cross-check failed (HTTP ${r.status}).` };
  } catch {
    state.cmc = { loading: false, data: state.cmc?.data ?? null, error: 'Could not reach the local server.' };
  }
  render();
}

const cmp = (label, v, fmt) => (v.coinmarketcap === null || v.coingecko === null
  ? `${label}: not compared`
  : `${label}: CoinGecko ${fmt(v.coingecko)} vs CoinMarketCap ${fmt(v.coinmarketcap)} (${v.diffPct > 0 ? '+' : ''}${v.diffPct.toFixed(1)}%, ${v.agrees ? 'within' : 'outside'} tolerance)`);

function cmcLead(x, attribution) {
  const [label, cls] = VERDICT_CHIP[x.verdict];
  return el('li', { class: 'lead' },
    el('div', {}, el('span', { class: 'name' }, x.name), ' ', el('span', { class: 'sym' }, `${x.symbol} · ${x.id}`), ' ', el('span', { class: `chip ${cls}` }, label)),
    el('p', { class: 'plain' }, plainCheck(x).text),
    el('div', { class: 'sym' }, MATCH_TEXT[x.match.status](x.match)),
    x.match.status === 'matched' ? el('ul', { class: 'notes' }, el('li', {}, cmp('Price', x.price, price)), el('li', {}, cmp('Market cap', x.marketCap, usd))) : null,
    x.tags.length ? el('div', { class: 'sym' }, `CoinMarketCap tags: ${x.tags.join(', ')}${x.providerCategory ? ` → ${x.providerCategory.category} (per tag "${x.providerCategory.tag}")` : ''}`) : null,
    x.notes.length ? el('ul', { class: 'notes caveats' }, ...x.notes.map((n) => el('li', { class: 'flag' }, n))) : null,
    x.match.status === 'matched' ? cmcAttribution(attribution, true) : null);
}

async function loadAttention(refresh = false) {
  const mode = state.last?.mode === 'live' ? 'live' : 'offline';
  state.attention = { loading: true, data: state.attention?.data ?? null, error: null };
  render();
  const send = (extra) => fetch('/api/crypto/trending', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-market-scanner': '1', accept: 'application/json' },
    body: JSON.stringify({ mode, refresh, ...extra }),
  }).then(async (r) => [r, await r.json()]);
  try {
    let [r, data] = await send({});
    if (r.status === 428 && data.needsConfirm) {
      if (!window.confirm(`Check CoinGecko's trending searches?\n\nThis sends 1 CoinGecko request (Demo plan: 100 per minute). The answer is cached for 30 minutes.\n\nLive search requests this session: ${data.liveRequestsThisSession} of ${data.sessionRequestLimit}.`)) {
        state.attention = { loading: false, data: state.attention?.data ?? null, error: null };
        return render();
      }
      [r, data] = await send({ confirmLive: true });
    }
    state.attention = data.ok ? { loading: false, data, error: null } : { loading: false, data: state.attention?.data ?? null, error: data.error || `The attention check failed (HTTP ${r.status}).` };
  } catch {
    state.attention = { loading: false, data: state.attention?.data ?? null, error: 'Could not reach the local server.' };
  }
  render();
}

function attentionView() {
  const box = el('div', { class: 'cmc' }, el('h4', {}, 'Attention: CoinGecko trending searches'),
    el('p', { class: 'muted small' }, 'Optional and separate from the scanner\'s score: shows which coins are among CoinGecko\'s most-searched in the last 24 hours, and marks them in the table. Search interest on one site only: not social media, not sentiment, not buying. Offline uses test data; live sends 1 CoinGecko request after you confirm (cached 30 minutes).'));
  const a = state.attention;
  const b = el('button', { type: 'button', class: 'secondary' }, a?.data ? 'Check again' : 'Check trending searches');
  b.disabled = Boolean(a?.loading);
  b.addEventListener('click', () => loadAttention(Boolean(a?.data && a.data.mode === 'live')));
  box.append(b);
  if (a?.loading) box.append(el('div', { class: 'running' }, el('span', { class: 'spinner' }), 'Checking…'));
  if (a?.error) box.append(el('div', { class: 'error' }, a.error));
  const d = a?.data;
  if (d) {
    if (d.dataKind === 'test_data') box.append(el('div', { class: 'banner test' }, 'TEST DATA: synthetic trending list with invented coins. NOT market data.'));
    const inScan = new Set((state.last?.rows ?? []).map((r) => r.id));
    const label = (c) => `#${c.trendRank} ${c.symbol}${c.marketCapRank ? ` (market-cap rank ${c.marketCapRank})` : ''}`;
    const hits = d.coins.filter((c) => inScan.has(c.id));
    const others = d.coins.filter((c) => !inScan.has(c.id));
    box.append(el('p', { class: 'kv' }, `${hits.length} of ${d.coins.length} trending coin(s) are in this scan${hits.length ? `: ${hits.map(label).join(', ')}` : ''}.`));
    if (others.length) box.append(el('p', { class: 'sym' }, `Trending but not in this scan (not evaluated; search them above): ${others.map(label).join(', ')}.`));
    box.append(el('ul', { class: 'notes' },
      el('li', {}, d.meaning),
      el('li', {}, `Source: ${d.source}. Fetched ${when(d.fetchedAt)}${d.fromCache ? ' (cached in memory; no request made)' : ''}; requests used: ${d.requestsUsed}.`)));
  }
  return box;
}

function cmcView() {
  const box = el('div', { class: 'cmc' }, el('h4', {}, 'Second source: CoinMarketCap'),
    el('p', { class: 'muted small' }, 'Cross-checks the scan\'s research leads (the coins in the table with a signal, plus those that moved but were not checked): price, market cap, category tags. Runs only when you click. Offline scans use test data; a live scan sends 1 CoinMarketCap request (about 2 credits) after you confirm.'));
  const c = state.cmc;
  const b = el('button', { type: 'button', class: 'secondary' }, c?.data ? 'Run the cross-check again' : 'Cross-check with CoinMarketCap');
  b.disabled = Boolean(c?.loading);
  b.addEventListener('click', () => loadCmc(Boolean(c?.data && c.data.mode === 'live')));
  box.append(b);
  if (c?.loading) box.append(el('div', { class: 'running' }, el('span', { class: 'spinner' }), 'Checking…'));
  if (c?.error) box.append(el('div', { class: 'error' }, c.error));
  const d = c?.data;
  if (d) {
    box.append(cmcAttribution(d.attribution));
    if (d.dataKind === 'test_data') box.append(el('div', { class: 'banner test' }, 'TEST DATA: synthetic CoinMarketCap listings with invented coins. NOT market data.'));
    const s = d.summary;
    box.append(el('p', { class: 'kv' }, `${s.leads} lead(s): ${s.matched} matched (${s.agrees} agree, ${s.differs} differ), ${s.ambiguous} ambiguous, ${s.unmatched} not matched, ${s.notFound} not found.`));
    box.append(el('ul', { class: 'leads' }, ...d.results.map((x) => cmcLead(x, d.attribution))));
    box.append(el('ul', { class: 'notes' },
      el('li', {}, `Source: ${d.source}. Fetched ${when(d.fetchedAt)}${d.fromCache ? ' (cached in memory; no request made)' : ''}; requests used: ${d.requestsUsed}${d.creditsUsed !== null && d.creditsUsed !== undefined ? `; credits reported: ${d.creditsUsed}` : ''}${d.mode === 'live' ? `; requests this session: ${d.cmcRequestsThisSession} of ${d.cmcSessionLimit}` : ''}.`),
      ...d.notes.map((n) => el('li', {}, n))));
  }
  return box;
}

function render() {
  const data = state.last;
  if (!data) return;
  const r = data.result;
  const s = r.scan;
  const root = $('results');
  root.replaceChildren();
  root.hidden = false;
  const synthetic = r.dataset.kind === 'synthetic';
  root.append(synthetic
    ? el('div', { class: 'banner test' }, `TEST DATA — synthetic ${data.market} fixture with invented names and numbers. NOT market data.`)
    : el('div', { class: 'banner live' }, `Live data from ${r.dataset.source}. ${r.dataset.attribution ?? ''}`));
  root.append(el('div', { class: 'status-row' },
    el('span', { class: `chip ${s.status}` }, s.status === 'complete' ? 'COMPLETE' : 'PARTIAL'),
    el('span', { class: 'muted' }, s.status === 'complete' ? 'Complete for the scanned scope (not a market-wide scan).' : s.partialReasons.join('; '))));
  if (s.nextStep) root.append(el('p', { class: 'kv' }, el('b', {}, 'Next step: '), dashboardWording(s.nextStep)));

  const controls = parseBudgetControls($('total-budget').value, $('unit-limit').value, $('no-unit-limit').checked, $('preference').value);
  const shownRows = data.rows.filter((row) => keepMove(row.change.short.value));
  const hiddenByDirection = data.rows.length - shownRows.length;
  const view = 'error' in controls ? null : buildView(shownRows, controls);
  const cov = r.dataset.coverage;
  root.append(el('p', { class: 'summary-line' }, [
    (() => {
      const names = shownRows.filter((row) => row.signal.status === 'qualified').map((row) => row.symbol);
      return `${names.length} signal(s) shown${names.length ? ` (${names.join(', ')})` : ''}`;
    })(),
    view ? `${view.counts.withinBudget} within your limits` : null,
    hiddenByDirection ? `${hiddenByDirection} hidden by Direction (${$('direction').value === 'up' ? 'falling or flat' : $('direction').value === 'down' ? 'rising or flat' : ''})` : null,
    `${data.rows.length} evaluated of ${r.universe} scanned`,
    cov ? `history ${cov.historyFetched} of ${cov.historyEligible}` : null,
    cov ? `${cov.requestsUsed} of ${cov.requestLimit} API requests used` : synthetic ? '0 API requests (offline)' : null,
  ].filter(Boolean).join(' · ')));
  const tr = trackRecordView(data.trackRecord, data.market);
  if (tr) root.append(tr);
  // Send the top movers of the main table to the Snapshot Log in one go (to check them on your phone).
  const top = view ? [...view.sections[0].rows].filter((x) => x.row.dataKind !== 'test_data')
    .sort((a, b) => Math.abs(b.row.change.short.value ?? 0) - Math.abs(a.row.change.short.value ?? 0)).slice(0, SEND_TOP).map((x) => x.row) : [];
  if (top.length) {
    root.append(el('p', { class: 'kv' }, el('a', { class: 'linkish', href: snapshotBatchLink(top), target: '_blank', rel: 'noopener noreferrer' },
      `Send these ${top.length} to Snapshot Log ↗`), ' ', el('span', { class: 'sym' }, `The top ${top.length} of "${view.sections[0].title}", biggest move first. Review and save them there, then check them on your phone in the Claude app.`)));
  }
  root.append(el('p', { class: 'kv' }, el('b', {}, 'Freshness: '), s.freshness));
  // Crypto live scans: how far the history requests got, in plain English, from the scan's own figures.
  const coverage = data.market === 'crypto' ? coverageSentences(coverageFigures(r)) : [];
  if (coverage.length) root.append(el('p', { class: 'kv' }, el('b', {}, 'Coverage: '), coverage.join(' ')));
  // Biggest move first (absolute short-period change; assets without one last). Display order only:
  // scores, sections and filters are unchanged.
  const move = (x) => (x.row.change.short.value === null ? -1 : Math.abs(x.row.change.short.value));
  const sectionView = (sec) => {
    const rows = [...sec.rows].sort((a, b) => move(b) - move(a));
    const body = rows.length
      ? el('div', { class: 'table-wrap' }, el('table', {},
        el('thead', {}, el('tr', {}, ...['Asset', 'Signal', 'Price', 'Change ↓', 'Your budget', 'Look closer'].map((h) => el('th', {}, h)))),
        el('tbody', {}, ...rows.flatMap((x) => [rowView(x), newsPanelRow(x.row), wtbPanelRow(x.row)].filter(Boolean)))))
      : el('p', { class: 'empty' }, s.status === 'partial' ? 'None among the assets evaluated in this partial scan.' : 'None.');
    return sec.collapsed
      ? el('details', { class: 'section' }, el('summary', {}, `${sec.title} (${sec.rows.length})`), body)
      : el('div', {}, el('h3', {}, `${sec.title} (${sec.rows.length})`), body);
  };
  // Crypto: the main budget table first ("Qualified signals within your budget and unit-price limit"),
  // then the research leads and their CoinMarketCap check, then the other budget sections.
  // Crypto: each evaluated coin's research-lead cautions show under its name in the table.
  state.leadById = new Map(r.discovery ? [...r.discovery.highPriority, ...r.discovery.watchlist].map((e) => [e.id, e]) : []);
  if (!view) root.append(el('div', { class: 'error' }, controls.error));
  else for (const sec of view.sections) root.append(sectionView(sec));
  if (r.discovery) root.append(discoveryView(r.discovery, coverage.length > 0));
  root.append(el('p', { class: 'muted small' }, 'Max whole units = floor(budget ÷ unit price), before fees; no fractional units assumed. Scores measure evidence strength, not expected returns. A research lead, not a recommendation.'));

  const groups = new Map();
  for (const e of r.excluded) {
    const reason = e.reasons[0];
    const g = groups.get(reason.code) ?? { count: 0, examples: [] };
    g.count++;
    if (g.examples.length < 8) g.examples.push(e.symbol);
    groups.set(reason.code, g);
  }
  // Reference material, folded: what was excluded and what the data cannot show.
  const more = el('details', { class: 'section' }, el('summary', {}, `Scanner details: ${r.excluded.length} excluded, data limits`));
  root.append(more);
  more.append(el('h3', {}, `Excluded by the scanner (${r.excluded.length}; first reason shown)`));
  if (data.market === 'crypto' && r.excluded.length > 0) {
    // Three different reasons, never combined: skipped for the request limit, data problems, scope rules.
    const b = exclusionBreakdown(r.excluded);
    const skipped = coverage.length > 0 ? 'skipped when history requests stopped (see Coverage above), not rejected by any rule' : 'skipped because history requests stopped before reaching them (request or rate limit; not rejected by any rule)';
    more.append(el('p', { class: 'kv' }, `Of these: ${b.budget_skipped} ${skipped}, ` +
      `${b.data} not evaluated because of missing, stale, implausible or unreliable data or a failed request, ` +
      `and ${b.rule} outside the scanner's scope or eligibility rules.`));
  }
  more.append(groups.size > 0
    ? el('ul', { class: 'excl' }, ...[...groups].sort((x, y) => y[1].count - x[1].count).map(([code, g]) =>
      el('li', {}, el('span', { class: 'count' }, String(g.count)), data.exclusionLabels?.[code] ?? code.replaceAll('_', ' '),
        el('div', { class: 'ex' }, `${g.examples.join(', ')}${g.count > g.examples.length ? `, +${g.count - g.examples.length} more` : ''}`))))
    : el('p', { class: 'empty' }, 'None.'));
  more.append(el('h3', {}, 'What this data cannot show'));
  more.append(el('ul', { class: 'notes' }, ...data.limitations.map((n) => el('li', {}, n))));
  const notes = r.dataset.notes ?? [];
  if (notes.length > 0) {
    more.append(el('h3', {}, 'Data notes'));
    more.append(el('ul', { class: 'notes' }, ...notes.map((n) => el('li', {}, n))));
  }
}

// ---- crypto asset search ----------------------------------------------------------------------
// Separate from scans: a search never starts one. Offline searches the TEST DATA fixture. Live sends
// a request only after the page asks you (the server answers 428 until confirmed; cached answers
// need no confirmation). Results are never auto-selected: you choose by name and CoinGecko id.

const MATCH_LABEL = { symbol: 'exact symbol', name: 'exact name', id: 'exact id', partial: 'partial match' };

/** POSTs to a search route; on 428 asks the user, then resends once with confirmLive. */
async function searchPost(path, body, what) {
  const send = async (extra) => {
    const r = await fetch(path, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-market-scanner': '1', accept: 'application/json' },
      body: JSON.stringify({ ...body, ...extra }),
    });
    return [r, await r.json()];
  };
  let [r, data] = await send({});
  if (r.status === 428 && data.needsConfirm) {
    const used = Number.isInteger(data.liveRequestsThisSession) ? `\n\nLive search requests this session: ${data.liveRequestsThisSession} of ${data.sessionRequestLimit}.` : '';
    if (!window.confirm(`${what}\n\nThis sends 1 CoinGecko request (Demo plan: 100 per minute).${used}`)) return { cancelled: true };
    [r, data] = await send({ confirmLive: true });
  }
  return { r, data };
}

function setSearchBusy(text) {
  $('search-status').hidden = !text;
  if (text) $('search-status-text').textContent = text;
  $('search-btn').disabled = Boolean(text);
}

function showSearchError(text) {
  $('search-error').textContent = text || '';
  $('search-error').hidden = !text;
}

async function runSearch(refresh = false) {
  const query = $('search-q').value.trim();
  const mode = checked('mode');
  showSearchError('');
  if (query.replace(/^\$/, '').length < 2) return showSearchError('Enter at least 2 characters of a name or symbol.');
  setSearchBusy(mode === 'live' ? 'Searching CoinGecko…' : 'Searching the synthetic test coins…');
  try {
    const res = await searchPost('/api/crypto/search', { mode, query, refresh }, `Search CoinGecko for "${query}"?`);
    if (res.cancelled) return;
    if (!res.data.ok) return showSearchError(res.data.error || `The search failed (HTTP ${res.r.status}).`);
    renderSearchResults(res.data);
  } catch {
    showSearchError('Could not reach the local server. Is "npm run web" still running?');
  } finally {
    setSearchBusy('');
  }
}

function renderSearchResults(d) {
  const root = $('search-results');
  $('asset-detail').replaceChildren();
  root.replaceChildren();
  root.hidden = false;
  if (d.dataKind === 'test_data') root.append(el('div', { class: 'banner test' }, 'TEST DATA: invented coins from the offline search fixture. NOT market data.'));
  if (d.guidance) root.append(el('p', { class: d.results.length ? 'warning' : 'empty' }, d.guidance));
  for (const a of d.ambiguousSymbols) {
    if (!d.guidance || !d.guidance.includes(` ${a.symbol}.`)) root.append(el('p', { class: 'sym' }, `Note: the symbol ${a.symbol} is shared by ${a.ids.length} results (${a.ids.join(', ')}).`));
  }
  if (d.results.length) {
    const shared = new Set(d.ambiguousSymbols.map((a) => a.symbol));
    root.append(el('ul', { class: 'search-list' }, ...d.results.map((c) => {
      const b = el('button', { type: 'button', class: 'secondary' }, 'Show market data');
      b.addEventListener('click', () => loadAsset(c, false));
      return el('li', {},
        el('div', {}, el('span', { class: 'name' }, c.name), ' ', el('span', { class: `chip ${shared.has(c.symbol) ? 'partial' : 'dim'}` }, c.symbol),
          el('div', { class: 'sym' }, `CoinGecko id: ${c.id} · ${c.rank ? `market-cap rank ${c.rank}` : 'no market-cap rank'} · ${MATCH_LABEL[c.match]}`)),
        b);
    })));
  }
  root.append(el('p', { class: 'sym' }, `${d.results.length} shown of ${d.total} match(es). Source: ${d.source}${d.attribution ? `. ${d.attribution}` : ''}. ${d.fromCache ? 'Cached result (no request made)' : `Requests used: ${d.requestsUsed}`}${d.mode === 'live' ? `; live search requests this session: ${d.liveRequestsThisSession} of ${d.sessionRequestLimit}` : ''}.`));
  if (d.mode === 'live') {
    const b = el('button', { type: 'button', class: 'linkish' }, 'Refresh this search (1 request)');
    b.addEventListener('click', () => runSearch(true));
    root.append(b);
  }
}

async function loadAsset(coin, refresh) {
  const mode = checked('mode');
  showSearchError('');
  setSearchBusy(`Loading ${coin.name} (${coin.symbol})…`);
  try {
    const res = await searchPost('/api/crypto/asset', { mode, id: coin.id, refresh }, `Load market data for ${coin.name} (${coin.symbol}, id ${coin.id})?`);
    if (res.cancelled) return;
    if (!res.data.ok) return showSearchError(res.data.error || `The lookup failed (HTTP ${res.r.status}).`);
    renderAsset(coin, res.data);
  } catch {
    showSearchError('Could not reach the local server. Is "npm run web" still running?');
  } finally {
    setSearchBusy('');
  }
}

const evText = (e, fmt) => (e.value === null ? `not available${e.note ? ` (${e.note})` : ''}` : fmt(e.value));

function renderAsset(coin, d) {
  const root = $('asset-detail');
  root.replaceChildren();
  // The chosen coin replaces the result list; "Back" shows the list again (no request).
  const list = $('search-results');
  list.hidden = true;
  const back = el('button', { type: 'button', class: 'linkish' }, '← Back to all search results');
  back.addEventListener('click', () => {
    root.replaceChildren();
    list.hidden = false;
  });
  root.append(back);
  const a = d.asset;
  const head = el('h3', {}, `${coin.name} (${coin.symbol})`);
  const card = el('div', { class: 'asset-card' }, head, el('div', { class: 'sym' }, `CoinGecko id: ${coin.id}`));
  if (d.dataKind === 'test_data') card.append(el('div', { class: 'banner test' }, 'TEST DATA: invented values. NOT market data.'));
  if (!a) {
    card.append(el('p', { class: 'empty' }, d.message));
  } else {
    const updated = a.lastUpdated.value;
    const age = updated && d.fetchedAt ? Math.round((Date.parse(d.fetchedAt) - Date.parse(updated)) / 60000) : null;
    card.append(el('div', { class: 'grid' },
      stat('Price (USD)', evText(a.price, price), a.rank.value ? `market-cap rank ${a.rank.value}` : 'no market-cap rank'),
      stat('24h change', evText(a.change24hPct, pct), `7d: ${evText(a.change7dPct, pct)}`),
      stat('24h volume', evText(a.volume24h, usd), 'USD, aggregated across exchanges'),
      stat('Market cap', evText(a.marketCap, usd), a.high24h.value !== null && a.low24h.value !== null ? `24h range ${price(a.low24h.value)} to ${price(a.high24h.value)}` : '24h range not available')));
    card.append(el('p', { class: 'kv' }, el('b', {}, 'Updated: '), updated ? `${when(updated)}${age !== null && age >= 0 ? ` (${age} min before it was fetched)` : ''}` : 'update time not provided'));
  }
  card.append(el('p', { class: 'kv' }, el('b', {}, 'Source: '), `${d.source}${d.attribution ? `. ${d.attribution}` : ''}`));
  card.append(el('p', { class: 'kv' }, el('b', {}, 'Fetched: '), `${when(d.fetchedAt)}${d.fromCache ? ' (cached; no request made)' : `; requests used: ${d.requestsUsed}`}`));
  const s = d.inLastScan;
  card.append(el('p', { class: 'kv' }, el('b', {}, 'Scanner: '), s
    ? `evaluated in the latest ${s.mode} scan: ${s.category ?? STATUS_LABEL[s.status]}${s.score !== null ? ` (evidence ${s.score}/${s.maxScore})` : ''}. Search does not change the scan.`
    : d.scanNote));
  if (d.mode === 'live') {
    const b = el('button', { type: 'button', class: 'linkish' }, 'Refresh market data (1 request)');
    b.addEventListener('click', () => loadAsset(coin, true));
    card.append(b);
  }
  // Project profile: only on request (1 CoinGecko request in live mode, after confirmation).
  const profileBox = el('div', { class: 'profile' });
  const pb = el('button', { type: 'button', class: 'linkish' }, `Show project profile${d.mode === 'live' ? ' (1 CoinGecko request)' : ''}`);
  pb.addEventListener('click', () => loadProfile(coin, d, profileBox, pb));
  card.append(pb, profileBox);
  card.append(el('p', { class: 'sym' }, 'Shown for research only. A search result is not a recommendation, and this tool cannot buy anything.'));
  root.append(card);
}

async function loadProfile(coin, d, box, button) {
  showSearchError('');
  setSearchBusy(`Loading the ${coin.name} profile…`);
  try {
    const res = await searchPost('/api/crypto/profile', { mode: d.mode, id: coin.id, refresh: false }, `Load the project profile for ${coin.name} (${coin.symbol}, id ${coin.id})?`);
    if (res.cancelled) return;
    if (!res.data.ok) return showSearchError(res.data.error || `The profile request failed (HTTP ${res.r.status}).`);
    button.hidden = true;
    renderProfile(box, res.data, d);
  } catch {
    showSearchError('Could not reach the local server. Is "npm run web" still running?');
  } finally {
    setSearchBusy('');
  }
}

const NA = 'Not available';
function profileRow(label, ...value) {
  return el('tr', {}, el('td', { class: 'pl' }, label), el('td', {}, ...value));
}

function renderProfile(box, r, d) {
  box.replaceChildren();
  const p = r.profile;
  box.append(el('div', { class: 'profile-head' }, 'About this crypto'));
  if (r.dataKind === 'test_data') box.append(el('div', { class: 'sym' }, 'TEST DATA: invented project.'));
  const rows = [];
  if (!p) {
    box.append(el('p', { class: 'empty' }, r.message || 'No profile available.'));
  } else {
    rows.push(profileRow('What it is', p.descriptionExcerpt ?? NA, p.descriptionExcerpt ? el('span', { class: 'sym' }, ' Project-provided text (CoinGecko), not verified.') : null));
    rows.push(profileRow('Launched', p.genesisDate ? `${p.genesisDate} ` : 'Unknown', p.genesisDate ? el('span', { class: 'sym' }, 'as listed by CoinGecko') : null));
    rows.push(profileRow('Purpose', p.categories.length ? `Categories: ${p.categories.join(', ')}` : NA, el('span', { class: 'sym' }, p.categories.length ? ' (CoinGecko)' : '')));
    rows.push(profileRow('Supply', supplyText(p)));
    const growth = (r.forecasts ?? []).flatMap((f) => f.growthFactors.map((g) => `${g} (${f.publisher}, ${f.published})`)).slice(0, 3);
    rows.push(profileRow('Why it might grow', growth.length ? el('ul', { class: 'plain-warnings' }, ...growth.map((g) => el('li', {}, g))) : 'Not available: no sourced research for this coin.', growth.length ? el('div', { class: 'sym' }, 'Sourced opinions, not facts.') : null));
    const ctx = profileContext(p, d.asset);
    rows.push(profileRow('Main risks', ctx.length ? el('ul', { class: 'plain-warnings' }, ...ctx.map((c) => el('li', { class: 'plain-caution' }, c))) : 'None found in this data (not proof of low risk).'));
    const links = [p.homepage ? el('a', { href: p.homepage, target: '_blank', rel: 'noopener noreferrer nofollow' }, 'Website') : null, p.whitepaper ? el('a', { href: p.whitepaper, target: '_blank', rel: 'noopener noreferrer nofollow' }, 'Whitepaper') : null].filter(Boolean);
    if (links.length) rows.push(profileRow('Links', ...links.flatMap((l, i) => (i ? [' · ', l] : [l]))));
    box.append(el('table', { class: 'profile-table' }, el('tbody', {}, ...rows)));
  }
  // 2030 outlook: curated, sourced, each source separate; the implied change uses one reference price.
  const ref = d.asset?.price?.value ?? null;
  const o = outlookView(r.forecasts, ref, d.asset?.lastUpdated?.value ?? null, new Date());
  box.append(el('div', { class: 'profile-head' }, '2030 outlook ', el('span', { class: 'sym' }, '· not a guarantee')));
  if (o.status === 'none') {
    box.append(el('p', { class: 'sym' }, o.message));
  } else {
    for (const e of o.entries) {
      box.append(el('div', { class: 'outlook' },
        el('div', {}, el('span', { class: 'chip cat' }, e.type === 'analyst_valuation_model' ? 'Analyst valuation model' : 'Model scenario'), ' ',
          el('b', {}, e.publisher), ` · published ${e.published}${e.dated ? ` (dated: ${e.ageMonths} months old)` : ''} · `,
          el('a', { href: e.url, target: '_blank', rel: 'noopener noreferrer' }, 'source')),
        el('div', {}, e.figures.map((x) => `${x.case[0].toUpperCase()}${x.case.slice(1)} ${e.approximate ? '~' : ''}$${x.value.toLocaleString()}${x.impliedPct === null ? '' : ` (${x.impliedPct > 0 ? '+' : ''}${x.impliedPct.toFixed(0)}%)`}`).join(' · '),
          e.approximate ? el('span', { class: 'sym' }, ' Approximate, as published.') : null),
        el('div', { class: 'sym' }, e.assumptions)));
    }
    box.append(el('p', { class: 'sym' }, [o.message, o.disagreement,
      o.reference ? `% change vs $${o.reference.price.toLocaleString()}, the CoinGecko USD price${o.reference.asOf ? ` at ${when(o.reference.asOf)}` : ''}.` : 'Implied change not available: no current price.'].filter(Boolean).join(' ')));
  }
  box.append(el('p', { class: 'sym' }, `Source: ${r.source}. Fetched ${when(r.fetchedAt)}${r.fromCache ? ' (cached; no request made)' : `; requests used: ${r.requestsUsed}`}.`));
}

document.addEventListener('DOMContentLoaded', () => {
  for (const f of ['controls', 'money']) $(f).addEventListener('submit', (e) => e.preventDefault());
  // Search runs only on an explicit submit (button or Enter), never while typing.
  $('search-form').addEventListener('submit', (e) => {
    e.preventDefault();
    runSearch();
  });
  document.querySelectorAll('input[name="mode"], input[name="market"]').forEach((r) => r.addEventListener('change', updateControls));
  $('max-requests').addEventListener('input', () => { updateControls(); prefs.set('maxRequests', $('max-requests').value); });
  $('auto-scan').checked = prefs.get('autoScan') === '1';
  $('auto-scan').addEventListener('change', () => prefs.set('autoScan', $('auto-scan').checked ? '1' : '0'));
  for (const id of ['total-budget', 'unit-limit', 'preference', 'direction']) {
    const v = prefs.get(id);
    if (v !== null) $(id).value = v;
    $(id).addEventListener('change', () => prefs.set(id, $(id).value));
  }
  // Budget controls re-filter the last result only: no request, no rescan.
  for (const id of ['total-budget', 'unit-limit', 'no-unit-limit', 'preference', 'direction']) {
    $(id).addEventListener('input', () => { updateControls(); render(); });
    $(id).addEventListener('change', () => { updateControls(); render(); });
  }
  $('scan-btn').addEventListener('click', () => {
    const req = currentRequest();
    if (req) scan(req);
  });
  $('rerun-btn').addEventListener('click', () => {
    if (state.lastRequest) {
      const { confirmLive: _c, ...again } = state.lastRequest;
      scan(again);
    }
  });
  loadStatus();
});
